package utils.observer;

public interface Observer {
    void update();
}