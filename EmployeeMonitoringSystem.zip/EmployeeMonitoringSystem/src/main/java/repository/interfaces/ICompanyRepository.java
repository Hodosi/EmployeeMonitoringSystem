package repository.interfaces;

import model.Company;

public interface ICompanyRepository extends IRepository<Integer, Company> {
}
